#include <iostream>
#include <vector>
#include <set>
#include <fstream>
#include <iomanip>
#include <ctime>
#include <cstdlib>
#include <algorithm>

using namespace std;

struct Cartela {
    int matriz[5][5];
    bool marcada[5][5] = {false}; 
};

vector<int> numerosUnicos(int min, int max, int quantidade) {
    set<int> numeros;
    while (static_cast<int>(numeros.size()) < quantidade) {
    numeros.insert(rand() % (max - min + 1) + min);
}
    return vector<int>(numeros.begin(), numeros.end());
}

Cartela novasCartelas() {
    Cartela cartela;
    vector<int> colunas[5] = {
        numerosUnicos(1, 15, 5),
        numerosUnicos(16, 30, 5),
        numerosUnicos(31, 45, 5),
        numerosUnicos(46, 60, 5),
        numerosUnicos(61, 75, 5)
    };

    for (int col = 0; col < 5; ++col) {
        for (int lin = 0; lin < 5; ++lin) {
            cartela.matriz[lin][col] = colunas[col][lin];
        }
    }

    cartela.matriz[2][2] = 0; 
    cartela.marcada[2][2] = true;

    return cartela;
}

void mostraCartelas(const Cartela& cartela) {
    cout << " B   I   N   G   O\n";
    for (int i = 0; i < 5; ++i) {
        for (int j = 0; j < 5; ++j) {
            if (cartela.matriz[i][j] == 0)
                cout << setw(3) << "F ";
            else if (cartela.marcada[i][j])
                cout << setw(3) << "* ";
            else
                cout << setw(3) << cartela.matriz[i][j] << " ";
        }
        cout << endl;
    }
}

bool marcarNumero(Cartela& cartela, int numero) {
    bool encontrado = false;
    for (int i = 0; i < 5; ++i) {
        for (int j = 0; j < 5; ++j) {
            if (cartela.matriz[i][j] == numero) {
                cartela.marcada[i][j] = true;
                encontrado = true;
            }
        }
    }
    return encontrado;
}

void verificaCartela(const Cartela& cartela) {
    for (int i = 0; i < 5; ++i) {
        if (all_of(cartela.marcada[i], cartela.marcada[i] + 5, [](bool marcado) { return marcado; })) {
            cout << "LINHA!" << endl;
        }
    }

    for (int j = 0; j < 5; ++j) {
        bool coluna = true;
        for (int i = 0; i < 5; ++i) {
            if (!cartela.marcada[i][j]) {
                coluna = false;
                break;
            }
        }
        if (coluna) {
            cout << "COLUNA!" << endl;
        }
    }

    bool bingo = true;
    for (int i = 0; i < 5; ++i) {
        for (int j = 0; j < 5; ++j) {
            if (!cartela.marcada[i][j]) {
                bingo = false;
            }
        }
    }
    if (bingo) {
        cout << "BINGO!" << endl;
    }
}

void salvaCartela(const Cartela& cartela, int numero) {
    ofstream arquivo("cartela_" + to_string(numero) + ".txt");
    arquivo << "  B   I   N   G   O\n";
    for (int i = 0; i < 5; ++i) {
        for (int j = 0; j < 5; ++j) {
            if (cartela.matriz[i][j] == 0)
                arquivo << setw(3) << "F ";
            else
                arquivo << setw(3) << cartela.matriz[i][j] << " ";
        }
        arquivo << endl;
    }
    arquivo.close();
}

int main() {
    srand(time(0));

    vector<Cartela> cartelas;
    set<int> numerosChamados;

    int opcao;
    do {
        cout << "\n--- Menu ---\n";
        cout << "1. Gerar cartelas\n";
        cout << "2. Exibir cartelas\n";
        cout << "3. Marcar numero\n";
        cout << "4. Verificar cartelas\n";
        cout << "5. Sair\n";
        cout << "Escolha uma opcao: ";
        cin >> opcao;

        if (opcao == 1) {
            int quantidade;
            cout << "Quantas cartelas deseja gerar? ";
            cin >> quantidade;
            cartelas.clear();
            for (int i = 0; i < quantidade; ++i) {
                Cartela nova = novasCartelas();
                cartelas.push_back(nova);
                salvaCartela(nova, i + 1); 
            }
            cout << quantidade << " cartelas geradas e salvas em arquivos.\n";
        } else if (opcao == 2) {
            for (size_t i = 0; i < cartelas.size(); ++i) {
                cout << "Cartela " << i + 1 << ":\n";
                mostraCartelas(cartelas[i]); 
                cout << endl;
            }
        } else if (opcao == 3) {
            int numero;
            cout << "Digite o numero sorteado: ";
            cin >> numero;

            numerosChamados.insert(numero);
            for (auto& cartela : cartelas) {
                if (marcarNumero(cartela, numero)) {
                    cout << "Numero " << numero << " marcado na cartela.\n";
                }
            }
        } else if (opcao == 4) {
            for (size_t i = 0; i < cartelas.size(); ++i) {
                cout << "Verificando Cartela " << i + 1 << ":\n";
                verificaCartela(cartelas[i]); 
            }
        }
    } while (opcao != 5);

    cout << "Numeros chamados: ";
    for (int numero : numerosChamados) {
        cout << numero << " ";
    }
    cout << endl;

    return 0;
}